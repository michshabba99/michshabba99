class ItemToPurchase:

    def __init__(self, name ="none", price=0, quantity =0):
        self._name = name
        self._price = price
        self._quantity = quantity
