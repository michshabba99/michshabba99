my_list = input()
text = my_list.split()

for word in text:
    freq = text.count(word)
    print(word, freq)