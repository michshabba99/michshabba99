class ItemToPurchase:

    def __init__(self):
        self._name = "none"
        self._price = 0
        self._quantity = 0
        self._description = "none"

    def item_name(self, name):
        self._name = name

    def item_price(self, price):
        self._price = price

    def item_quantity(self, quantity):
        self._quantity = quantity

    def item_description(self, description):
        self._description = description

    def __str__(self):
        print("For item " + self._name + ": " + self._description + " there are " + str(self._quantity) + " available at $" + str(self._price) + ".")

    def print_item_cost(self):
        print(self._name + " " + str(self._quantity) + " @ $" + str(self._price) + " = $" + str(self._quantity * self._price))

    def print_item_description(self):
        print(self._name + ": " + self._description)

class ShoppingCart:

    def __init__(self, name="none", date="February 1, 2016"):
        self.cart_items = []
        self._customer_name = name
        self._current_date = date

    def add_item(self, cartItem):
        self.cart_items.append(cartItem)

    def remove_item(self, item_name):
        count = 0
        itms = self.cart_items[:]
        for i in range(len(itms)):
            itm = itms[i]
            if itm._name == item_name:
                del self.cart_items[i]
                count += 1

        if count == 0:
            print(" ")
            print("Item not found in cart. Nothing removed.")

    def modify_item(self, ItemToPurchase):
        count = 0
        itms = self.cart_items[:]
        for i in range(len(itms)):
            itm = itms[i]
            if itm._name == ItemToPurchase._name:
                count += 1
                if ItemToPurchase._description != "none":
                    itm.item_description(ItemToPurchase._description)
                if ItemToPurchase._price != 0:
                    itm.item_price(ItemToPurchase._price)
                if ItemToPurchase._quantity != 0:
                    itm.item_quantity(ItemToPurchase._quantity)

        if count == 0:
            print(" ")
            print("Item not found in cart. Nothing modified.")

    def get_num_items_in_cart(self):
        count = 0
        itms = self.cart_items[:]
        for i in range(len(itms)):
            itm = itms[i]
            count += itm._quantity

        return count

    def get_cost_of_cart(self):
        cost = 0
        itms = self.cart_items[:]
        for i in range(len(itms)):
            itm = itms[i]
            cost += (itm._quantity * itm._price)

        return cost

    def print_total(self):
        print(self._customer_name + "'s Shopping Cart - " + self._current_date)
        count = len(self.cart_items)
        if count == 0:
            print(" ")
            print("SHOPPING CART IS EMPTY")
            return 0

        print("Number of Items: " + str(count))
        print(" ")

        for itm in self.cart_items:
            itm.print_item_cost()

        total = self.get_cost_of_cart()
        print("Total: $" + str(total))

    def print_descriptions(self):
        print(self._customer_name + "'s Shopping Cart - " + self._current_date)
        print(" ")
        print("Item Descriptions")

        for itm in self.cart_itmes:
            print(itm.item_name() + ": " + itm.item_description())

def print_menu(cart):
    print(" ")
    print("MENU")
    print("a - Add item to cart")
    print("r - Remove item from cart")
    print("c - Change item quntity")
    print("i - Output items' descriptions")
    print("o - Output shopping cart")
    print("q - Quit")
    print(" ")

def main():
    #Define Constants and variables
    custName = ""
    dateToday = ""
    custName = input("Enter customer's name: ")
    dateToday = input("Enter today's date: ")
    print("Customer name: " + custName)
    print("Today's date: " + dateToday)
    myCart = ShoppingCart(custName,dateToday)

    option = ""

    while option != "q":
        print_menu(myCart)
        option = input("Choose an option: ").lower().strip()
        if option == "o":
            myCart.print_descriptions()
        elif option == "a":
            print("ADD ITEM TO CART")
            itemName = input("Enter the item name: ")
            itemDescr = input("Enter the item description: ")
            itemPrice = int(input("Enter the item price: "))
            itemQuantity = int(input("Enter the item quantity: "))
            print(" ")
            cartItem = ItemToPurchase()
            cartItem.item_name(itemName)
            cartItem.item_description(itemDescr)
            cartItem.item_price(itemPrice)
            cartItem.item_quantity(itemQuantity)
            myCart.add_item(cartItem)
        elif option == "r":
            print("REMOVE ITEM FROM CART")
            itemName = input("Enter name of item to remove: ")
            myCart.remove_item(itemName)
        elif option == "c":
            print("CHANGE ITEM QUNATITY")
            itemName = input("Enter the item name: ")
            itemQuantity = int(input("Enter the new quantity: "))
            changeItem = ItemToPurchase(itemName)
            changeItem.item_quantity(itemQuantity)
            myCart.modify_item(changeItem)

main()